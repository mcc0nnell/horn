# Horn derived research bundle v2.1

Public-safe structural export of the Horn corpus recovery work.

This directory contains derived topology, geometry, identifiers, relation counts, attribution/work links, bibliography normalization, validation reports, worldview identities/links, schemas, and provenance metadata. It intentionally excludes verbatim claim bodies, full worldview/postulate text, and Bob Horn's source PDFs.

## Why the redaction boundary exists

Robert E. Horn supplied the source material directly to Robert McConnell and granted permission to print the maps. That correspondence does not by itself establish a general public-republication or derivative-work license. The public repository therefore records the recovered structure without republishing the source corpus.

See `WITHHELD-SOURCE-MANIFEST.json` for the source-bearing artifacts held outside the public tree.

## Structural totals

- 7 maps
- 808 numbered claim identities
- 802 verified within-map typed relations
- 8 explicit cross-map typed argument relations
- 101 explicit cross-map references
- 3 relation kinds recovered from the posters: `is_supported_by`, `is_disputed_by`, `is_interpreted_as`
- 17 worldview/framework identities in the compiled Worldviews artifact

The `.horn.json` product format remains separate from this research export.
